#define UPX_VERSION_HEX         0x030000        /* 03.00.00 */
#define UPX_VERSION_STRING      "3.00"
#define UPX_VERSION_STRING4     "3.00"
#define UPX_VERSION_DATE        "Apr 27th 2007"
#define UPX_VERSION_DATE_ISO    "2007-04-27"
#define UPX_VERSION_YEAR        "2007"
